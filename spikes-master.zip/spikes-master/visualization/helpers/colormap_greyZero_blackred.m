function map = colormap_greyZero_blackred()
%
map=hot(1000);
% map = map(end:-1:1,:);

map(1,:) = [0.4 0.4 0.4];
